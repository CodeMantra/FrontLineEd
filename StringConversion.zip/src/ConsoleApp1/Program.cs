﻿using System;
using System.Linq;

namespace ConsoleApp1
{
    /// <summary>
    /// application to split the string and print individual words in the order set by the user
    /// </summary>
    public class Program
    {
        static string _replacementString = "~|~";

        public static void Main(string[] args)
        {
            string inputString = "(id,created,employee(id,firstname,employeeType(id), lastname),location)";

            try
            {
                bool printInAlphabeticOrder = TakeUserInput();

                Console.WriteLine("\n");

                // verify that there are equal number of opening and closing round brackets
                int startBracketCount = inputString.Split('(').Length - 1;
                int endBracketCount = inputString.Split(')').Length - 1;

                // validate string for equal number of openign and closign brackets
                if (!IsValidString(inputString, startBracketCount, endBracketCount))
                {
                    return;
                }

                // remove all the spaces
                inputString = inputString.Replace(", ", ",");

                // define an array to hold patter match result
                string[] bracketContent = new string[startBracketCount];

                // match the patterns
                // get the innermost bracket with its content
                int startBracketIndex = 0;
                int endBracketIndex = 0;

                // pattern match and split the string by pattern: (###)
                for (int counter = startBracketCount - 1; counter >= 0; counter--)
                {
                    // get the index of innermost start and end bracket
                    startBracketIndex = inputString.LastIndexOf("(");
                    endBracketIndex = inputString.IndexOf(")");

                    // get the content of innermost bracket
                    bracketContent[counter] = inputString.Substring(startBracketIndex + 1, endBracketIndex - startBracketIndex - 1);

                    // replace in the original string 
                    if (printInAlphabeticOrder)
                    {
                        inputString = inputString.Replace("(" + bracketContent[counter] + ")", string.Format("{0}", _replacementString));
                    }
                    else
                    {
                        // note we are appending the replacement string to the , in string.Format
                        inputString = inputString.Replace("(" + bracketContent[counter] + ")", string.Format(",{0}", _replacementString));
                    }
                }

                // print the words to console
                PrintStringAtIndex(bracketContent, 0, printInAlphabeticOrder);

                SetConsoleColor(ConsoleColor.Green);
            }
            catch(Exception ex)
            {
                SetConsoleColor(ConsoleColor.Red);
                Console.WriteLine("An error occured, please see the stack trace below.\n");
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }

        /// <summary>
        /// take the user input to set the order to print the words in the string
        /// </summary>
        /// <returns></returns>
        private static bool TakeUserInput()
        {
            SetConsoleColor(ConsoleColor.Yellow);
            Console.WriteLine("Enter 1 to print the words in alphabetical order, press any key to print in the pre-set order: ");
            
            bool returnValue = false;

            // set the return value
            if (Console.ReadKey().KeyChar.Equals('1'))
            {
                returnValue = true;
                Console.WriteLine("\nPrinting in alphabetical order...");
            }
            else
            {
                Console.WriteLine("\nPrinting in pre-set order...");
            }

            SetConsoleColor(ConsoleColor.White);
            return returnValue;
        }

        /// <summary>
        /// validate the string for matching opening and closing round brackets
        /// </summary>
        /// <param name="inputString"></param>
        /// <param name="startBracketCount"></param>
        /// <param name="endBracketCount"></param>
        /// <returns></returns>
        private static bool IsValidString(string inputString, int startBracketCount, int endBracketCount)
        {
            if (startBracketCount != endBracketCount || startBracketCount == 0)
            {
                Console.WriteLine("Invalid input string");

                // validation failed do not proceed
                return false;
            }

            return true;
        }

        /// <summary>
        /// split the array element at index by , and print in the order set by the user
        /// </summary>
        /// <param name="stringArray"></param>
        /// <param name="arrayIndex"></param>
        /// <param name="sortAlphabetically"></param>
        private static void PrintStringAtIndex(string[] stringArray, int arrayIndex, bool sortAlphabetically)
        {
            string hyphen = string.Empty;

            // get the number of hyphens as defined by array index
            for (int index = 0; index < arrayIndex; index++)
            {
                hyphen = string.Format("-{0}", hyphen);
            }

            if (!string.IsNullOrEmpty(hyphen))
            {
                hyphen = hyphen + " ";
            }

            //first split
            var splitStringArray = stringArray[arrayIndex].Split(',');

            // sort the array
            if (sortAlphabetically)
            {
                Array.Sort(splitStringArray);
            }

            // split by comma and write to console
            // call PrintStringAtIndex recursively to print the next index 
            splitStringArray.ToList().ForEach
                ( s=>
                    {
                        if (s.Contains(_replacementString))
                        {
                            if (sortAlphabetically)
                            {
                                Console.WriteLine(string.Format("{0}{1}", hyphen, s.Replace(_replacementString, string.Empty)));
                            }

                            // write the next index
                            PrintStringAtIndex(stringArray, arrayIndex + 1, sortAlphabetically);
                        }
                        else
                        {
                            Console.WriteLine(string.Format("{0}{1}", hyphen, s));
                        }
                    }
                );
        }

        /// <summary>
        /// set the console color
        /// </summary>
        /// <param name="color"></param>
        private static void SetConsoleColor(ConsoleColor color)
        {
            Console.ForegroundColor = color;
        }
    }
}
