﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrontLineSample
{
    class Program
    {

        static void Main(string[] args)
        {
            string input = "(id,created,employee(id,firstname,employeeType(id), lastname),location)";

            // print in sorted order
            PrintInSetAndSortedOrder(input);

            Console.WriteLine("\n\nPress any key to exit...");
            Console.ReadKey();
        }

        private static void WriteHeaderText(string headerText)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(headerText);
            Console.WriteLine("\n------------------------");
            Console.ForegroundColor = ConsoleColor.White;
        }

        private static void PrintInSetAndSortedOrder(string input)
        {
            int numWords = 0;

            // find the number of words
            foreach (char c in input)
            {
                if (c.Equals(',') || c.Equals('('))
                {
                    numWords++;
                }
            }

            // create an array where we will sort and add the entries
            string[] arrayOfWords = new string[numWords];

            // varible to keep count to number of '-' to add
            int numberOfDashes = 0;

            // we will loop through the chars in input string and append character one at a time
            string currentString = string.Empty;

            // index where current item was added to the array
            int arrayIndex = 0;

            // write the header to first print in set order
            WriteHeaderText("\nPrinting in set order: ");

            foreach (char c in input)
            {
                // special case handle beging rouud bracket
                if (c.Equals('(') || c.Equals(')') || c.Equals(','))
                {
                    // this might be a beginning of new word if this is not the first occurance
                    if (!string.IsNullOrEmpty(currentString))
                    {
                        if(numberOfDashes > 1)
                        {
                            currentString = new String('-', numberOfDashes - 1) + " " + currentString.Trim();
                        }
                        else
                        {
                            currentString = new String('-', numberOfDashes - 1) + currentString.Trim();
                        }
                        

                        // write to console in set order
                        Console.WriteLine(currentString);

                        // sort and add to array, we will then printed from the sorted array
                        arrayIndex = SortAndAddToArray(currentString, arrayOfWords, numberOfDashes, arrayIndex);
                    }

                    // we need to increase the number of deshes after encountering the opening round bracket
                    if (c.Equals('(')) { numberOfDashes++; }
                    else if (c.Equals(')')) { numberOfDashes--; }

                    currentString = string.Empty;
                }
                else
                {
                    currentString += c;
                }
            }

            // now print in sorted order
            WriteHeaderText("\n\n\nPrinting in sorted order: ");

            foreach (string str in arrayOfWords)
            {
                if (!string.IsNullOrEmpty(str)) { Console.WriteLine(str); }
            }
        }

        private static int SortAndAddToArray(string currentString, string[] arrayOfWords, int numberOfDashes, int startAtPosition)
        {
            int endIndex = 0;
            int lastWordIndex = 0;

            // we have the start index for sort, now get the index to end sort
            if (arrayOfWords[startAtPosition] != null && arrayOfWords[startAtPosition].Split('-').Length == (numberOfDashes - 1))
            {
                if (arrayOfWords[startAtPosition + 1] != null && arrayOfWords[startAtPosition + 1].Split('-').Length == (numberOfDashes - 1))
                {
                    endIndex = startAtPosition + 1;
                    lastWordIndex = endIndex;

                    // we know the exact position, this is when we encounter a new opening round bracket 
                    // and we want to add a new -
                    if (lastWordIndex > 0)
                    {
                        ShiftAtIndex(arrayOfWords, lastWordIndex);
                        arrayOfWords[lastWordIndex] = currentString;
                        return lastWordIndex;
                    }
                }
            }
            else
            {
                endIndex = GetEndIndex(arrayOfWords, numberOfDashes);
            }

            // index of first non "-" lower case alphabet
            int firstCharIndex = 0; 

            if (numberOfDashes > 1)
            {
                firstCharIndex = numberOfDashes;
            }
            else
            {
                firstCharIndex = numberOfDashes - 1;
            }

                for (int index = startAtPosition; index <= endIndex; index++)
            {
                lastWordIndex = index;

                // find the insert position
                // compare the first character
                // currently we only sort based on first character, more elaborate algorithm can be written for full string sorting
                if (arrayOfWords[startAtPosition] == null)
                {
                    arrayOfWords[index] = currentString;
                    break;
                }
                else if (arrayOfWords[index][firstCharIndex] > currentString[firstCharIndex])
                {
                    // if we have to shift items in array
                    ShiftAtIndex(arrayOfWords, index);
                    arrayOfWords[index] = currentString;
                    break;
                }
                else if (lastWordIndex == endIndex)
                {
                    // verify if there we can shift word to next indexes in array
                    if (index < arrayOfWords.Length - 2)
                    {
                        ShiftAtIndex(arrayOfWords, index + 1);
                    }

                    arrayOfWords[index + 1] = currentString;
                    break;
                }
            }

            return lastWordIndex;
        }

        private static void ShiftAtIndex(string[] arrayOfWords, int index)
        {
            string currentIndexValue = arrayOfWords[index];
            string nextIndexValue = arrayOfWords[index + 1];

            // shift all the array elements from current index to next index in array
            while (currentIndexValue != null)
            {
                arrayOfWords[index + 1] = currentIndexValue;

                currentIndexValue = nextIndexValue;
                nextIndexValue = arrayOfWords[index + 2];
                index++;
            }
        }

        private static int GetStartIndex(string[] arrayOfWords, int numberOfDashes)
        {
            // find the last word with number of dashes
            // if not found return the first null array element
            for (int index = 0; index < arrayOfWords.Length; index++)
            {
                if (string.IsNullOrEmpty(arrayOfWords[index]) || arrayOfWords[index].Split('-').Length - 1 == numberOfDashes)
                {
                    // we encountered the first null element
                    return index;
                }
            }

            // we cannot find anything?? this will not happen
            return 0;
        }

        private static int GetEndIndex(string[] arrayOfWords, int numberOfDashes)
        {
            // find the last word with number of dashes
            // if not found return the first null array element
            int lastIndex = 0;
            for (int index = 0; index < arrayOfWords.Length; index++)
            {
                if (string.IsNullOrEmpty(arrayOfWords[index]))
                {
                    // if we have last index return last index, this is the index of last non null array element
                    // else return index
                    if (lastIndex > 0) { return lastIndex; }
                    else { return index; }
                }
                else if (arrayOfWords[index].Split('-').Length == numberOfDashes)
                {
                    lastIndex = index;
                }
            }
            return lastIndex;
        }

    }
}
